#! /bin/sh
eval '(exit $?0)' && eval 'PERL_BADLANG=x;PATH="$PATH:.";export PERL_BADLANG\
;exec perl -T -x -S -- "$0" ${1+"$@"};#'if 0;eval 'setenv PERL_BADLANG x\
;setenv PATH "$PATH":.;exec perl -T -x -S -- "$0" $argv:q;#'.q
#!perl -wi.bak
+push@INC,'.';$0=~/(.*)/s;do(index($1,"/")<0?"./$1":$1);die$@if$@__END__+if 0
;#Don't touch/remove lines 1--7: http://pts.github.io/Magic.Perl.Header
#
# magicc.pl -- the Magic Perl Header adder
# by pts@fazekas.hu at Sat Mar 30 17:42:52 CET 2002
# Sun Apr  7 10:52:27 CEST 2002
# sub remover added at Fri May 31 20:07:17 CEST 2002
# adder for v5 at Sat Dec  7 18:49:20 CET 2002
# v6 at Wed Feb 12 10:42:37 CET 2003
# Speedy at Tue Jan  3 21:08:11 CET 2006
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# magicc.pl modifies the beginning of Perl scripts so that they will run on
# any UNIX system, whatever shell the user uses and wherever the perl binary
# is located. (This uses Magic Perl Header 7.)
#
# The -T command line switch (which turns on secure tainted mode) should be
# specified separetely in the first line of the input file, for example:
#
#	#! perl -wn -T
#

# use integer; use strict;
# ^^^ neither integer, nor strict is an essential part of magicc.pl. We want
# to continue without errors of these don't exist.
BEGIN { eval { require integer; import integer } ;
        eval { require strict ; import strict  } }

die "This is magicc.pl, the Header Wizard for Magic Perl|Speedy Header 7.
GNU GPL >=2.0. Written and (C) Early January 2006 by pts\@fazekas.hu.

Usage: $0 <perl-script.pl>\n" if $#ARGV;
my @stat; die "$0: script not found: $ARGV[0]\n" unless @stat=stat$ARGV[0];
my $O=$stat[2]&07777; $O|=($O&0444)>>2; # add executable bits
$O=~/(.*)/s; $O=$1; $ARGV[0]=~/(.*)/s; $ARGV[0]=$1; my $fname=$1;
printf STDERR"%s: chmod %04o failed: %s\n", $0,$O,$fname
  unless chmod $O, $fname;
if (defined($_=<>)) {
  my($OPTS,$SPEEDYOPTS,$TAINT,$PRE)=("","","","");
  my $htype=0;
  if (/^#!.*?perl(\s+(.*))?/i) {
    $OPTS=defined($1)?$2:"";
    $htype=1;
  } elsif (/^#!.*?speedy(\s+(.*))?/i) {
    $OPTS=defined($1)?$2:"";
    $htype=15;
    $SPEEDYOPTS=$1 if $OPTS=~s/(?:\A|\s+)--\s*(.*)//s;   
  } elsif (/\A#![ \t]*\/bin\/sh(?:[ \t]*--)?$/) {
    my $lineleft=25;
    while (<>) {
      if (/Magic[.]Perl[.]Header/) { $htype=2; last }
      elsif (/Magic[.]Speedy[.]Header/) { $htype=13; last }
      last if 0==--$lineleft;
      $OPTS.=" $1" if /^#!.*?perl\s+(.*)/i and 0==length($OPTS);
      $OPTS.=" $1" if /exec perl ([^;]*?) -x /;
      $OPTS.=" $1" if /setenv P "([^"]*)"/;
      $SPEEDYOPTS.=" $1" if /setenv S "\$P -- ([^"]*)"/;
    }
    die "$0: existing Magic Perl Header not ended; clobbering: $fname\n" if $htype==0;
  } else { $PRE=$_; $htype=4 }
  # Dat: don't remove duplicates from $OPTS, not needed
  $OPTS=" $OPTS ";
  $OPTS=~s@\s+@ @g;
  $TAINT=" -T" while $OPTS=~s@ -T @ @g;
  die unless $OPTS=~s@ $@@;
  $SPEEDYOPTS=" $SPEEDYOPTS ";
  $SPEEDYOPTS=~s@\s+@ @g;
  die unless $SPEEDYOPTS=~s@ $@@;
  if ($htype>9) { # Dat: emit Magic.Speedy.Header
    my $OPTS2=$OPTS;
    $OPTS2=~s@\A\s+@@;
    if (0!=length $TAINT) { $TAINT=~s@\A\s+@@; $TAINT=~s@\s*\Z(?!\n)@ @ }
    print q`#! /bin/sh
eval '(exit $?0)'&&eval 'setenv(){ A="$2";eval $1=\"\$A\";export $1;};#'.q%
setenv P "`.$TAINT.$OPTS2.q`";setenv S "$P --`.$SPEEDYOPTS.q`";setenv D "$P -eshift=~/(.*)/\
;do(("\$0=\$1")=~m,^.?.?/,?"\$0:qq,./\$0,\)\;die\$@if\$@;setenv A true
setenv PERL_BADLANG false;$A&&which speedy>/dev/null&&exec speedy $S:q \
"$0" $argv:q;$A&&exec perl $D:q "$0" $argv:q
type speedy>/dev/null 2>&1&&exec speedy $S "$0" ${1+"$@"}   
exec perl $D "$0" ${1+"$@"};% if 0;BEGIN{delete$INC{__FILE__||q
#!perl`.$OPTS.q`
+$0=~/(.*)/;do(($0=$1)=~m,^.?.?/,?$0:"./$0");die$@if$@;__END__+}}
#"# Don't touch lines 1--11: http://pts.github.io/Magic.Speedy.Header
`.$PRE;
  } else { # Dat: emit Magic.Perl.Header
    # print "#! perl$TAINT;\n#!perl $OPTS;\n";
    # vvv Dat: `export PATH' is needed for dumb /bin/sh on Solaris
    #     !! better PATH-finding for `.' in CGI
    print q`#! /bin/sh
eval '(exit $?0)' && eval 'PERL_BADLANG=x;PATH="$PATH:.";export PERL_BADLANG\
 PATH;exec perl`.$TAINT.q` -x -S -- "$0" ${1+"$@"};#'if 0;eval 'setenv PERL_BADLANG x\
;setenv PATH "$PATH":.;exec perl`.$TAINT.q` -x -S -- "$0" $argv:q;#'.q
#!perl`.$OPTS.q`
+push@INC,'.';$0=~/(.*)/s;do(index($1,"/")<0?"./$1":$1);die$@if$@__END__+if 0
;#Don't touch/remove lines 1--7: http://pts.github.io/Magic.Perl.Header
`.$PRE;
  }
  print while <>;
}
__END__
